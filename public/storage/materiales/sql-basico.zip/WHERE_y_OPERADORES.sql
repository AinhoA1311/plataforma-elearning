-- Filtros con WHERE
SELECT * FROM alumnos WHERE edad > 18 AND ciudad = 'Madrid';