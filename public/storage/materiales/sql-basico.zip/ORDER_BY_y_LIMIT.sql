-- Ordenar y limitar resultados
SELECT nombre, nota FROM alumnos ORDER BY nota DESC LIMIT 5;