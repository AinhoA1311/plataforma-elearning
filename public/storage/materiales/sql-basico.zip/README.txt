EJERCICIOS BÁSICOS DE SQL
-------------------------
Estos ejercicios están pensados para practicar:
- SELECT
- WHERE y operadores
- ORDER BY y LIMIT
- INSERT, UPDATE y DELETE