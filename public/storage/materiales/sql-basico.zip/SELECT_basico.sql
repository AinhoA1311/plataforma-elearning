-- Consulta básica
SELECT * FROM alumnos;