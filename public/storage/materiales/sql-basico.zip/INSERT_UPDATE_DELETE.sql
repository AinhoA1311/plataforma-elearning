-- Insertar, actualizar y eliminar datos
INSERT INTO alumnos (nombre, edad) VALUES ('Ainhoa', 22);
UPDATE alumnos SET edad = 23 WHERE nombre = 'Ainhoa';
DELETE FROM alumnos WHERE nombre = 'Ainhoa';